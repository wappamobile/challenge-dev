# Projeto
Instruções de uso e testes dentro da pasta bin

Demorei aproximadamente 6 horas para execução utilizando o intervalo de almoço do trabalho e o fim da noite de 12/12 e 13/12.

Abraços
